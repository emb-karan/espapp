
2)Command :
    
    pip install espapp-pkg
    
  ## if pip not installed and getting error, run the below command and then re-run previous command
  
    sudo apt update
    sudo apt install python-pip
    
    
  # for ubuntu version >= 19.1
    
    pip3 install espapp-pkg
    
  ## if pip not installed and getting error, run the below command and then re-run previous command
   
    sudo apt update
    sudo apt install python3-pip
    

3)Command :

    sudo espapp -h
    

