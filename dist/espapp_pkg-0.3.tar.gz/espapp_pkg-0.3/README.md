1)Command :

    sudo python setup.py develop

# for ubuntu version >= 19.1
    
    sudo python setup.py develop

2)Command :
    
    pip install application
    
  ## if pip not installed and getting error, run the below command and the re-run previous command
  
    sudo apt update
    sudo apt install python-pip
    
    
  # for ubuntu version >= 19.1
    
    pip3 install application
    
  ## if pip not installed and getting error, run the below command and the re-run previous command
   
    sudo apt update
    sudo apt install python3-pip
    

3)Command :

    sudo application -h
    

